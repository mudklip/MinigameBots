MinigameBots 1.18.0 for Minecraft Java 26.3 (Fabric)
==================================================

Install (once)
1. Run fabric-installer-1.1.2.jar (double-click; needs Java). Choose Client, Minecraft 26.3,
   Loader 0.20.1 or newer, and press Install.
2. Copy everything in the "mods" folder of this package into your .minecraft/mods folder
   (Windows: press Win+R, type %appdata%\.minecraft and open "mods"; create it if missing).
3. Start the launcher, pick the "fabric-loader-26.3" profile and play.

What's in mods/
- minigamebots-1.18.0.jar            the AI (client mod)
- minigamebots-training-1.18.0.jar   Training Grounds (arenas, dummies, matches). Works in
                                    singleplayer; for a server, put it in the server's mods too.
- fabric-api, yet-another-config-lib   libraries both need

Optional
- optional/baritone-api-fabric-1.20.0.jar: copy into mods only if you want the Baritone
  teacher demos (travel, mining, go home). Don't use it on servers that forbid it.

First steps in game (easiest: F10 > ★ Training Hub; the Guide, F10 > Guide, explains everything)
1. Press F10 > Brain > Install: downloads Python and PyTorch for the AI (one time, a few GB;
   your RTX GPU is used automatically).
2. F10 > AI Profiles: make an AI. Record yourself with F7, then Train it, or use
   Teacher demos / Aim drill to train without any skill from you.
3. F8 gives control to the AI or takes it back; F9 is the emergency stop.

Everything is in the F10 menu; Settings > Autonomy and safety has session limits, auto-respawn,
chat replies (off by default) and protected-zone size. See licenses/ for third-party licences.
Optional extras (all local): F10 > Brain > Mind for /ai commands in plain words and chat in
character, Voice for push-to-talk (hold B). Multi-world training: /tg multitrain (see the Guide).

Only let the AI play on worlds and servers where you're allowed to.
